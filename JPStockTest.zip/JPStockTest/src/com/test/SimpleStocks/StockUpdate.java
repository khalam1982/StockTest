package com.test.SimpleStocks;

import java.util.HashMap;
import java.util.Map;

public class StockUpdate {
	
	

}
